#! /bin/sh

export QT_QPA_FB_TSLIB=1
./supervision_system_demo
