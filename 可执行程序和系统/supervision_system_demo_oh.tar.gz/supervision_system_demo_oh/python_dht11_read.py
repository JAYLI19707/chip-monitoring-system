from RPi.GPIO import DHT_sensor

# 设置传感器类型: 支持 DHT11 , DHT22 和 AM2302
sensor=DHT_sensor.DHT11

# 设置 GPIO 的编号 ls2k300 pai 上链接的 gpio 编号是 61
pin = 61

while True:
    result, humidity, temperature = DHT_sensor.read_retry(sensor, pin)

    if result == 0:
        print('humidity={0:0.0f} temperature={1:0.0f}'.format(humidity, temperature))
        break
