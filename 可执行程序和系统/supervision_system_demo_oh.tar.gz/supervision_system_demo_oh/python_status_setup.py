from RPi.GPIO import LED #导入LED模块
from RPi.GPIO import Buzzer #导入 Buzzer 模块
import time
import sys

def main():
    if len(sys.argv) < 2:
        return

    led_r = LED(88) #红灯初始化，连接的是pin 88
    led_y = LED(72) #黄灯初始化，连接的是pin 72
    led_g = LED(73) #绿灯初始化，连接的是pin 73
    beep = Buzzer(75, active_high=False) # 蜂鸣器初始化 链接的是 pin75 低电平时发出响声

    if sys.argv[1] == '0':
        led_g.on()
        led_r.off()
        led_y.off()
        beep.off()
    elif sys.argv[1] == '1':
        led_g.off()
        led_r.on()
        led_y.off()
        beep.on()
    elif sys.argv[1] == '2':
        led_g.off()
        led_r.off()
        led_y.on()
        beep.on()
    elif sys.argv[1] == '3':
        led_g.off()
        led_r.on()
        led_y.on()
        beep.on()
    elif sys.argv[1] == '4':
        led_g.off()
        led_r.off()
        led_y.off()
        beep.off()

    time.sleep(0.1)

if __name__ == "__main__":
    main()